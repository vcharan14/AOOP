package ridesharing.vehicles;

public class Car extends Vehicle {
    @Override
    public void bookRide() {
        System.out.println("Car ride booked!");
    }
}
