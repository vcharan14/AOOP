package ridesharing.vehicles;

public class Scooter extends Vehicle {
    @Override
    public void bookRide() {
        System.out.println("Scooter ride booked!");
    }
}
