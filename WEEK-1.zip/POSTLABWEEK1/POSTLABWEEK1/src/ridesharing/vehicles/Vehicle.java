package ridesharing.vehicles;

public abstract class Vehicle {
    public abstract void bookRide();
}
