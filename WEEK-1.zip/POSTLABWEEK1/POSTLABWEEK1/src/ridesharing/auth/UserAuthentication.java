package ridesharing.auth;

public class UserAuthentication {
    private static UserAuthentication instance;
    private String loggedInUser;

    private UserAuthentication() {}

    public static UserAuthentication getInstance() {
        if (instance == null) {
            instance = new UserAuthentication();
        }
        return instance;
    }

    public void login(String username) {
        this.loggedInUser = username;
        System.out.println(username + " has logged in.");
    }

    public void logout() {
        System.out.println(loggedInUser + " has logged out.");
        this.loggedInUser = null;
    }

    public String getLoggedInUser() {
        return loggedInUser;
    }
}
