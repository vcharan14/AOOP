package mypakcage;

public interface AbstaractFactory {
	Weapon createWeapon();
	PowerUp createPowerUp();
}
