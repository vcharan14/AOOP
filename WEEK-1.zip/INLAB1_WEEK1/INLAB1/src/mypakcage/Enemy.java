package mypakcage;

abstract class Enemy {
	public abstract void attack();
}

class zombie extends Enemy{
	public void attack() {
		System.out.println("zombie attacks!");
	}
	
}
class vampire extends Enemy {
	public void attack() {
		System.out.println("vampire attack!");
	}
}


