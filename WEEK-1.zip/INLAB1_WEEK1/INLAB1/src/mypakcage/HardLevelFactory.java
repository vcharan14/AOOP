package mypakcage;

public class HardLevelFactory implements AbstaractFactory{
	public Weapon createWeapon() {
		return new Gun();
	}
	public PowerUp createPowerUp() {
		return new SpeedBoost();
	}

}
