package mypakcage;

public class GameAplication {
	public static void main(String args[]) {
		GameState gamestate=GameState.getInstance();
		System.out.println("Game level:"+gamestate.getLevel());
		System.out.println("Game Difficulty:"+gamestate.getDifficulty());
		
		EnemyFactory enemyfactory=new ZombieFactory();
		Enemy enemy=enemyfactory.createEnemy();
		enemy.attack();
		
		enemyfactory =new VampireFactory();
		enemy=enemyfactory.createEnemy();
		enemy.attack();
		
		
		AbstaractFactory factory=new EasyLevelFactory();
		Weapon weapon=factory.createWeapon();
		PowerUp powerup=factory.createPowerUp();
		weapon.use();
		powerup.activate();
		
		factory=new HardLevelFactory();
		weapon=factory.createWeapon();
		powerup=factory.createPowerUp();
		weapon.use();
		powerup.activate();
		
	}
}
