package mypakcage;

public class HealthBoost implements PowerUp{
	public void activate() {
		System.out.println("Health Boost is Activated");
	}

}
