/**
 * 
 */

document.addEventListener("DOMContentLoaded", () => {
  // Fade-in effect for .container
  const container = document.querySelector(".container");
  if (container) {
    container.style.opacity = 0;
    container.style.transform = "translateY(20px)";
    container.style.transition = "opacity 1s ease, transform 1s ease";
    setTimeout(() => {
      container.style.opacity = 1;
      container.style.transform = "translateY(0)";
    }, 200);
  }

  // Add hover effects to buttons
  const buttons = document.querySelectorAll("button, .btn");
  buttons.forEach(button => {
    button.addEventListener("mouseenter", () => {
      button.style.transform = "scale(1.05)";
    });
    button.addEventListener("mouseleave", () => {
      button.style.transform = "scale(1)";
    });
  });

  // Add a subtle pulse animation to the header
  const header = document.querySelector("header");
  if (header) {
    header.style.animation = "pulse 2s infinite";
  }
});

// Keyframes for pulse animation
const styleSheet = document.createElement("style");
styleSheet.innerHTML = `
  @keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.02); }
    100% { transform: scale(1); }
  }
`;
document.head.appendChild(styleSheet);