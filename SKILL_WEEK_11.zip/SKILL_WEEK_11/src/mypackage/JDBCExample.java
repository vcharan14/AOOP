package mypackage;

import java.sql.*;

public class JDBCExample {
    // Database credentials
    private static final String URL = "jdbc:postgresql://localhost:5432/testdb";
    private static final String USER = "your_username";
    private static final String PASSWORD = "your_password";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            System.out.println("Connected to the database.");

            // Perform CRUD operations
            insertStudent(conn, "Alice", 22, "Computer Science");
            insertStudent(conn, "Bob", 24, "Electronics");
            retrieveStudents(conn);
            updateStudentAge(conn, 1, 23);
            deleteStudent(conn, 2);
            retrieveStudents(conn);

        } catch (SQLException e) {
            System.err.println("Database error: " + e.getMessage());
        }
    }

    // Insert a new student record
    public static void insertStudent(Connection conn, String name, int age, String department) {
        String sql = "INSERT INTO students (name, age, department) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setInt(2, age);
            pstmt.setString(3, department);
            pstmt.executeUpdate();
            System.out.println("Inserted student: " + name);
        } catch (SQLException e) {
            System.err.println("Insert error: " + e.getMessage());
        }
    }

    // Retrieve and display student records
    public static void retrieveStudents(Connection conn) {
        String sql = "SELECT * FROM students";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("\nStudent Records:");
            while (rs.next()) {
                System.out.printf("ID: %d, Name: %s, Age: %d, Department: %s%n",
                        rs.getInt("id"), rs.getString("name"), rs.getInt("age"), rs.getString("department"));
            }
        } catch (SQLException e) {
            System.err.println("Retrieve error: " + e.getMessage());
        }
    }

    // Update student age
    public static void updateStudentAge(Connection conn, int id, int newAge) {
        String sql = "UPDATE students SET age = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, newAge);
            pstmt.setInt(2, id);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Updated student ID " + id + " age to " + newAge);
            }
        } catch (SQLException e) {
            System.err.println("Update error: " + e.getMessage());
        }
    }

    // Delete a student record
    public static void deleteStudent(Connection conn, int id) {
        String sql = "DELETE FROM students WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Deleted student with ID: " + id);
            }
        } catch (SQLException e) {
            System.err.println("Delete error: " + e.getMessage());
        }
    }
}
