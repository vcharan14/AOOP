package adapterpattern;

public class Main {
    public static void main(String[] args) {
        GalleryApp galleryApp = new GalleryApp();

        // Display PNG image
        galleryApp.show("png", "image1.png");

        // Display JPG image
        galleryApp.show("jpg", "image2.jpg");

        // Invalid file type
        galleryApp.show("gif", "image3.gif");
    }
}
