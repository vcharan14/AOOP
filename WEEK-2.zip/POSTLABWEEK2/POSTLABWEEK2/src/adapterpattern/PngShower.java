package adapterpattern;

public class PngShower implements AdvancedImageViewer {
    @Override
    public void showPng(String fileName) {
        System.out.println("Displaying PNG image: " + fileName);
    }

    @Override
    public void showJpg(String fileName) {
        // Not supported in PngShower
    }
}
