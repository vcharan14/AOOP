package adapterpattern;

public class GalleryApp implements ImageViewer {
    private ImageAdapter imageAdapter;

    @Override
    public void show(String fileType, String fileName) {
        if (fileType.equalsIgnoreCase("png") || fileType.equalsIgnoreCase("jpg")) {
            imageAdapter = new ImageAdapter(fileType);
            imageAdapter.show(fileType, fileName);
        } else {
            System.out.println("Invalid file type: " + fileType + ". Supported types are PNG and JPG.");
        }
    }
}
