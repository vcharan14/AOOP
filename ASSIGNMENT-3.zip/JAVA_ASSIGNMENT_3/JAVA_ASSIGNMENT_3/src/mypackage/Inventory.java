package mypackage;

//Shared Inventory Class
class Inventory {
 private int stock = 0;
 private final int MAX_STOCK = 10; // Maximum inventory limit

 // Method for adding stock (Supplier)
 public synchronized void restock() {
     while (stock >= MAX_STOCK) {
         try {
             System.out.println("Stock full! Supplier waiting...");
             wait(); // Wait if stock is full
         } catch (InterruptedException e) {
             Thread.currentThread().interrupt();
         }
     }
     stock++;
     System.out.println("Supplier restocked. Current stock: " + stock);
     notify(); // Notify consumers
 }

 // Method for purchasing stock (Customer)
 public synchronized void purchase() {
     while (stock == 0) {
         try {
             System.out.println("Stock empty! Customer waiting...");
             wait(); // Wait if out of stock
         } catch (InterruptedException e) {
             Thread.currentThread().interrupt();
         }
     }
     stock--;
     System.out.println("Customer purchased. Remaining stock: " + stock);
     notify(); // Notify suppliers
 }
}

//Producer (Supplier) Thread
class Supplier extends Thread {
 private final Inventory inventory;

 public Supplier(Inventory inventory) {
     this.inventory = inventory;
 }

 @Override
 public void run() {
     while (true) {
         inventory.restock();
         try {
             Thread.sleep(1000); // Simulate restocking time
         } catch (InterruptedException e) {
             Thread.currentThread().interrupt();
         }
     }
 }
}

//Consumer (Customer) Thread
class Customer extends Thread {
 private final Inventory inventory;

 public Customer(Inventory inventory) {
     this.inventory = inventory;
 }

 @Override
 public void run() {
     while (true) {
         inventory.purchase();
         try {
             Thread.sleep(1500); // Simulate customer buying time
         } catch (InterruptedException e) {
             Thread.currentThread().interrupt();
         }
     }
 }
}
