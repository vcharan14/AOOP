package mypackage;

public class Main{
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        // Creating supplier and customer threads
        Supplier supplier = new Supplier(inventory);
        Customer customer = new Customer(inventory);

        supplier.start();
        customer.start();
    }
}