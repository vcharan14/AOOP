package p1;

class Car extends Vehicle {
   Car() {
   }

   public void requestRide() {
      System.out.println("Car ride requested!");
   }
}