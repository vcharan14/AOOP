package p1;

class Scooter extends Vehicle {
   Scooter() {
   }

   public void requestRide() {
      System.out.println("Scooter ride requested!");
   }
}
