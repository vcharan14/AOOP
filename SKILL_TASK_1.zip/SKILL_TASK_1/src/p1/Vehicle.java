package p1;

abstract class Vehicle {
   Vehicle() {
   }

   public abstract void requestRide();
}
