package p1;

interface RideFactory {
   Vehicle createVehicle();
}
