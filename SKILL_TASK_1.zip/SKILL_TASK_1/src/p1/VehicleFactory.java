package p1;

class VehicleFactory {
   VehicleFactory() {
   }

   public static Vehicle getVehicle(String type) {
      if (type.equalsIgnoreCase("car")) {
         return new Car();
      } else if (type.equalsIgnoreCase("bike")) {
         return new Bike();
      } else {
         return type.equalsIgnoreCase("scooter") ? new Scooter() : null;
      }
   }
}
