package p1;

class CarFactory implements RideFactory {
   CarFactory() {
   }

   public Vehicle createVehicle() {
      return new Car();
   }
}