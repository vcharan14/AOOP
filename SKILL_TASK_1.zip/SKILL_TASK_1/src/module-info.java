/**
 * 
 */
/**
 * 
 */
module SKILL_TASK_1 {
}