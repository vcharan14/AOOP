package mypackage;

class Producer implements Runnable {
    private BoundedBuffer buffer;

    // Constructor
    public Producer(BoundedBuffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        int item = 1;
        try {
            while (true) {
                buffer.produce(item++);
                Thread.sleep(500); // Simulate delay
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
