package mypackage;

class Producer implements Runnable {
    private MessageQueue messageQueue;

    // Constructor
    public Producer(MessageQueue messageQueue) {
        this.messageQueue = messageQueue;
    }

    @Override
    public void run() {
        int messageCount = 1;
        try {
            while (true) {
                String message = "Message " + messageCount++;
                messageQueue.produce(message);
                Thread.sleep(1000); // Simulate delay
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
