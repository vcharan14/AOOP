package mypackage;

public class Main{
    public static void main(String[] args) {
        MessageQueue sharedQueue = new MessageQueue();

        // Create producer and consumer threads
        Thread producerThread = new Thread(new Producer(sharedQueue), "Producer");
        Thread consumerThread = new Thread(new Consumer(sharedQueue), "Consumer");

        // Start threads
        producerThread.start();
        consumerThread.start();
    }
}

