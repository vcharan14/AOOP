package mypackage;

class Consumer implements Runnable {
    private MessageQueue messageQueue;

    // Constructor
    public Consumer(MessageQueue messageQueue) {
        this.messageQueue = messageQueue;
    }

    @Override
    public void run() {
        try {
            while (true) {
                messageQueue.consume();
                Thread.sleep(2000); // Simulate processing time
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
