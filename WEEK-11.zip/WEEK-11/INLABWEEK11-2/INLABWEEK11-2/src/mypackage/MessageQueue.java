package mypackage;

import java.util.LinkedList;
import java.util.Queue;

class MessageQueue {
    private Queue<String> queue = new LinkedList<>();
    private final int CAPACITY = 5;

    // Synchronized method to add messages
    public synchronized void produce(String message) throws InterruptedException {
        while (queue.size() == CAPACITY) {
            wait(); // Wait if buffer is full
        }
        queue.add(message);
        System.out.println("Produced: " + message);
        notify(); // Notify consumers
    }

    // Synchronized method to consume messages
    public synchronized String consume() throws InterruptedException {
        while (queue.isEmpty()) {
            wait(); // Wait if buffer is empty
        }
        String message = queue.poll();
        System.out.println("Consumed: " + message);
        notify(); // Notify producers
        return message;
    }
}
