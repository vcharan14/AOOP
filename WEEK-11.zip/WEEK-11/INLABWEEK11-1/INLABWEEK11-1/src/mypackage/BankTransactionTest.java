package mypackage;

public class BankTransactionTest {
    public static void main(String[] args) {
        // Create a shared BankAccount object with an initial balance
        BankAccount account = new BankAccount(500);

        // Create multiple transaction threads
        Thread user1 = new Thread(new TransactionThread(account, true, 200), "User 1");
        Thread user2 = new Thread(new TransactionThread(account, false, 100), "User 2");
        Thread user3 = new Thread(new TransactionThread(account, false, 300), "User 3");
        Thread user4 = new Thread(new TransactionThread(account, true, 500), "User 4");
        Thread user5 = new Thread(new TransactionThread(account, false, 700), "User 5");

        // Start the threads
        user1.start();
        user2.start();
        user3.start();
        user4.start();
        user5.start();
    }
}