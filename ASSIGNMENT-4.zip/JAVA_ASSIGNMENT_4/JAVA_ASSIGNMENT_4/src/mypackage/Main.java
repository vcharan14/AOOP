package mypackage;

public class Main {
    public static void main(String[] args) {
        TicketBookingSystem bookingSystem = new TicketBookingSystem(5); // Total 5 seats

        // Simulating multiple users trying to book tickets concurrently
        User user1 = new User(bookingSystem, 2, "Alice");
        User user2 = new User(bookingSystem, 2, "Bob"); // Competing for the same seat
        User user3 = new User(bookingSystem, 4, "Charlie");
        User user4 = new User(bookingSystem, 5, "David");
        User user5 = new User(bookingSystem, 5, "Eve"); // Competing for the same seat

        user1.start();
        user2.start();
        user3.start();
        user4.start();
        user5.start();
    }
}