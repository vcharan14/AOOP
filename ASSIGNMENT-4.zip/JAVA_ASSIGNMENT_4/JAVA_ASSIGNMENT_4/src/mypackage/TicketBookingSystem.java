package mypackage;

import java.util.*;

class TicketBookingSystem {
    private final int totalSeats;
    private final Set<Integer> bookedSeats = new HashSet<>();

    public TicketBookingSystem(int totalSeats) {
        this.totalSeats = totalSeats;
    }

    // Synchronized method to book a seat
    public synchronized boolean bookSeat(int seatNumber, String userName) {
        if (seatNumber <= 0 || seatNumber > totalSeats) {
            System.out.println(userName + ": Invalid seat number " + seatNumber);
            return false;
        }
        	
        if (!bookedSeats.contains(seatNumber)) {
            bookedSeats.add(seatNumber);
            System.out.println(userName + " successfully booked seat " + seatNumber);
            return true;
        } else {
            System.out.println(userName + ": Seat " + seatNumber + " is already booked.");
            return false;
        }
    }
}

// User Thread for Booking
class User extends Thread {
    private final TicketBookingSystem bookingSystem;
    private final int seatNumber;
    private final String userName;

    public User(TicketBookingSystem bookingSystem, int seatNumber, String userName) {
        this.bookingSystem = bookingSystem;
        this.seatNumber = seatNumber;
        this.userName = userName;
    }

    @Override
    public void run() {
        bookingSystem.bookSeat(seatNumber, userName);
    }
}

