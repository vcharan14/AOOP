package generics;

public class Main {
    public static void main(String[] args) {
        Integer[] intArray = {5, 2, 9, 1, 7};
        System.out.println("Before Sorting (Integer): ");
        BubbleSort.printArray(intArray);
        BubbleSort.bubbleSort(intArray);
        System.out.println("After Sorting (Integer): ");
        BubbleSort.printArray(intArray);

        Double[] doubleArray = {3.5, 2.1, 4.8, 1.9, 3.0};
        System.out.println("\nBefore Sorting (Double): ");
        BubbleSort.printArray(doubleArray);
        BubbleSort.bubbleSort(doubleArray);
        System.out.println("After Sorting (Double): ");
        BubbleSort.printArray(doubleArray);

        String[] strArray = {"Banana", "Apple", "Mango", "Cherry", "Grape"};
        System.out.println("\nBefore Sorting (String): ");
        BubbleSort.printArray(strArray);
        BubbleSort.bubbleSort(strArray);
        System.out.println("After Sorting (String): ");
        BubbleSort.printArray(strArray);
    }
}