package generics;

public class Main {
    public static void main(String[] args) {
        Integer[] intArray = {10, 20, 30, 40, 50, 60, 70};
        BinarySearch<Integer> intSearch = new BinarySearch<>(intArray);
        intSearch.printArray();
        System.out.println("Searching for 30: Found at index " + intSearch.search(30));
        System.out.println("Searching for 25: Found at index " + intSearch.search(25));

        Double[] doubleArray = {5.5, 1.2, 8.3, 3.9, 6.7};
        BinarySearch<Double> doubleSearch = new BinarySearch<>(doubleArray);
        doubleSearch.printArray();
        System.out.println("Searching for 3.9: Found at index " + doubleSearch.search(3.9));
        System.out.println("Searching for 2.0: Found at index " + doubleSearch.search(2.0));

        String[] strArray = {"Banana", "Apple", "Mango", "Cherry", "Grape"};
        BinarySearch<String> strSearch = new BinarySearch<>(strArray);
        strSearch.printArray();
        System.out.println("Searching for 'Mango': Found at index " + strSearch.search("Mango"));
        System.out.println("Searching for 'Pineapple': Found at index " + strSearch.search("Pineapple"));
    }
}