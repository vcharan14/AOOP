import sis.model.Student;
import sis.model.Course;
import sis.services.EnrollmentService;

public class Main {
    public static void main(String[] args) {
        // Create students
        Student student1 = new Student(1, "Alice");
        Student student2 = new Student(2, "Bob");

        // Create courses
        Course course1 = new Course(101, "Mathematics");
        Course course2 = new Course(102, "Computer Science");

        // Enrollment service
        EnrollmentService enrollmentService = new EnrollmentService();

        // Enroll students in courses
        enrollmentService.enrollStudentInCourse(student1, course1);
        enrollmentService.enrollStudentInCourse(student2, course2);
        enrollmentService.enrollStudentInCourse(student1, course2);

        // Display student and course details
        System.out.println("\nStudent Details:");
        System.out.println(student1);
        System.out.println(student2);

        System.out.println("\nCourse Details:");
        System.out.println(course1);
        System.out.println(course2);
    }
}
