package sis.services;

import sis.interfaces.Enrollable;
import sis.model.Student;
import sis.model.Course;

public class EnrollmentService implements Enrollable {
    @Override
    public void enrollStudentInCourse(Student student, Course course) {
        student.enrollInCourse(course.getCourseName());
        course.addStudent(student);
        System.out.println("Enrollment successful: " + student.getName() + " -> " + course.getCourseName());
    }
}
