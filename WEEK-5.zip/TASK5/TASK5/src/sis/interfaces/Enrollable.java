package sis.interfaces;

import sis.model.Student;
import sis.model.Course;

public interface Enrollable {
    void enrollStudentInCourse(Student student, Course course);
}
