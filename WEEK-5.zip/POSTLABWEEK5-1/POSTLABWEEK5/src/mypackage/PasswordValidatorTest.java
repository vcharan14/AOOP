package mypackage;
import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

public class PasswordValidatorTest {

    @Test
    public void testValidPassword() {
        PasswordValidator validator = new PasswordValidator();
        assertTrue(validator.isValidPassword("Abc123"));
    }

    @Test
    public void testPasswordTooShort() {
        PasswordValidator validator = new PasswordValidator();
        assertFalse(validator.isValidPassword("Abc12"));
    }

    @Test
    public void testPasswordTooLong() {
        PasswordValidator validator = new PasswordValidator();
        assertFalse(validator.isValidPassword("Abc123456789"));
    }

    @Test
    public void testEmptyPassword() {
        PasswordValidator validator = new PasswordValidator();
        assertFalse(validator.isValidPassword(""));
    }
}
