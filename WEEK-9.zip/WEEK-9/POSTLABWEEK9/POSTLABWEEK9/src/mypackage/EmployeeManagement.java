package mypackage;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EmployeeManagement {
    public static void main(String[] args) {
        // Creating a list of employees
        List<Employee> employees = Arrays.asList(
            new Employee(101, "Alice", "HR", 60000, 30),
            new Employee(102, "Bob", "IT", 75000, 28),
            new Employee(103, "Charlie", "Finance", 85000, 35),
            new Employee(104, "David", "IT", 92000, 40),
            new Employee(105, "Eve", "HR", 67000, 29),
            new Employee(106, "Frank", "Finance", 78000, 38),
            new Employee(107, "Grace", "IT", 80000, 26)
        );

        // 1️⃣ Filter employees based on department
        String targetDept = "IT";
        System.out.println("\nEmployees in Department: " + targetDept);
        employees.stream()
                 .filter(emp -> emp.getDepartment().equalsIgnoreCase(targetDept))
                 .forEach(System.out::println);

        // 2️⃣ Sort employees by salary in descending order
        System.out.println("\nEmployees sorted by Salary (Descending):");
        employees.stream()
                 .sorted((e1, e2) -> Double.compare(e2.getSalary(), e1.getSalary()))
                 .forEach(System.out::println);

        // 3️⃣ Group employees by department
        System.out.println("\nEmployees Grouped by Department:");
        Map<String, List<Employee>> groupedByDept = employees.stream()
                .collect(Collectors.groupingBy(Employee::getDepartment));
        groupedByDept.forEach((dept, empList) -> {
            System.out.println(dept + ": " + empList);
        });

        // 4️⃣ Find the highest-paid employee
        System.out.println("\nHighest Paid Employee:");
        employees.stream()
                 .max(Comparator.comparingDouble(Employee::getSalary))
                 .ifPresent(System.out::println);

        // 5️⃣ Calculate the average salary of employees in a department
        String deptToAnalyze = "Finance";
        System.out.println("\nAverage Salary in " + deptToAnalyze + " Department:");
        employees.stream()
                 .filter(emp -> emp.getDepartment().equalsIgnoreCase(deptToAnalyze))
                 .mapToDouble(Employee::getSalary)
                 .average()
                 .ifPresent(avg -> System.out.println("$" + avg));

        // 6️⃣ List names of employees earning more than a specified amount
        double salaryThreshold = 70000;
        System.out.println("\nEmployees earning more than $" + salaryThreshold + ":");
        employees.stream()
                 .filter(emp -> emp.getSalary() > salaryThreshold)
                 .map(Employee::getName)
                 .forEach(System.out::println);
    }
}
