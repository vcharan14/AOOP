package services;

import models.Employee;
import java.util.*;
import java.util.function.Predicate;

public class SalaryDistributor {
    private List<Employee> employees;

    public SalaryDistributor(List<Employee> employees) {
        this.employees = employees;
    }

    public void distributeSalariesWithBonus() {
        // Sort employees by experience (Descending order)
        Collections.sort(employees);

        // Predicate for filtering employees with experience > 2 years
        Predicate<Employee> isEligibleForBonus = emp -> emp.getExperience() > 2;

        // Process salary and bonuses
        for (Employee emp : employees) {
            if (isEligibleForBonus.test(emp)) {
                emp.addBonus(500);  // Adding a fixed bonus of $500
            }
        }
    }

    public void displayEmployees() {
        System.out.println("\n--- Employee Salary Distribution ---");
        employees.forEach(System.out::println);
    }
}
