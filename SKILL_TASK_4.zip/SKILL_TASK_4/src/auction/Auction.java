package auction;

public abstract class Auction {
    public final void startAuction() {
        initializeAuction();
        acceptBids();
        concludeAuction();
    }

    protected abstract void initializeAuction();
    protected abstract void acceptBids();
    protected abstract void concludeAuction();
}
