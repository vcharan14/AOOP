package auction;

public class Main {
    public static void main(String[] args) {
        Auctioneer auctioneer = new Auctioneer("Antique Vase");

        Observer bidder1 = new Bidder("Alice");
        Observer bidder2 = new Bidder("Bob");

        auctioneer.registerBidder(bidder1);
        auctioneer.registerBidder(bidder2);

        Auction auction = new LiveAuction(auctioneer);
        auction.startAuction();
    }
}
