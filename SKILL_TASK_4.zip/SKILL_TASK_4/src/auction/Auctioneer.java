package auction;
import java.util.ArrayList;
import java.util.List;

public class Auctioneer {
    private List<Observer> bidders = new ArrayList<>();
    private String item;
    private double highestBid;

    public Auctioneer(String item) {
        this.item = item;
        this.highestBid = 0.0;
    }

    public void registerBidder(Observer bidder) {
        bidders.add(bidder);
    }

    public void placeBid(double amount) {
        if (amount > highestBid) {
            highestBid = amount;
            notifyBidders();
        } else {
            System.out.println("Bid of $" + amount + " is too low.");
        }
    }

    private void notifyBidders() {
        for (Observer bidder : bidders) {
            bidder.update(item, highestBid);
        }
    }

    public double getHighestBid() {
        return highestBid;
    }
}
