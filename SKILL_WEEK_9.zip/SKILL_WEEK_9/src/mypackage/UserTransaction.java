package mypackage;

class UserTransaction extends Thread {
    private BankAccount account;
    private boolean isDeposit;
    private double amount;

    // Constructor
    public UserTransaction(BankAccount account, boolean isDeposit, double amount) {
        this.account = account;
        this.isDeposit = isDeposit;
        this.amount = amount;
    }

    // Run Method (Thread Execution)
    public void run() {
        if (isDeposit) {
            account.deposit(amount);
        } else {
            account.withdraw(amount);
        }
    }
}
