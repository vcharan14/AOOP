package mypackage;

class BankAccount {
    private double balance;

    // Constructor
    public BankAccount(double initialBalance) {
        this.balance = initialBalance;
    }

    // Synchronized Deposit Method
    public synchronized void deposit(double amount) {
        System.out.println(Thread.currentThread().getName() + " depositing: " + amount);
        balance += amount;
        System.out.println("New Balance after deposit: " + balance);
    }

    // Synchronized Withdraw Method
    public synchronized void withdraw(double amount) {
        if (balance >= amount) {
            System.out.println(Thread.currentThread().getName() + " withdrawing: " + amount);
            balance -= amount;
            System.out.println("New Balance after withdrawal: " + balance);
        } else {
            System.out.println(Thread.currentThread().getName() + " - Insufficient funds!");
        }
    }

    // Get Balance
    public double getBalance() {
        return balance;
    }
}

