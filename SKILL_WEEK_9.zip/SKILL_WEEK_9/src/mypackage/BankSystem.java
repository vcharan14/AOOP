package mypackage;

public class BankSystem {
    public static void main(String[] args) {
        BankAccount account = new BankAccount(1000); // Initial balance: 1000

        // Creating Multiple Threads for Deposits and Withdrawals
        Thread user1 = new UserTransaction(account, true, 500);  // Deposit 500
        Thread user2 = new UserTransaction(account, false, 300); // Withdraw 300
        Thread user3 = new UserTransaction(account, false, 700); // Withdraw 700
        Thread user4 = new UserTransaction(account, true, 200);  // Deposit 200

        // Start Threads
        user1.start();
        user2.start();
        user3.start();
        user4.start();
    }
}
