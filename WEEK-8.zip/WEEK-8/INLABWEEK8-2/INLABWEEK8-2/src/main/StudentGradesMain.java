package main;

import models.StudentGradesManager;
import java.util.Scanner;

public class StudentGradesMain {
    public static void main(String[] args) {
        StudentGradesManager gradeManager = new StudentGradesManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Student Grade Manager ---");
            System.out.println("1. Add Student Grade");
            System.out.println("2. Get Student Grades");
            System.out.println("3. Display All Student Grades");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Student ID: ");
                    int studentID = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter Grade: ");
                    String grade = scanner.nextLine();
                    gradeManager.addGrade(studentID, grade);
                    break;

                case 2:
                    System.out.print("Enter Student ID: ");
                    int searchID = scanner.nextInt();
                    System.out.println("Grades: " + gradeManager.getGrades(searchID));
                    break;

                case 3:
                    gradeManager.displayAllGrades();
                    break;

                case 4:
                    System.out.println("Exiting Student Grade Manager. Goodbye!");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}
