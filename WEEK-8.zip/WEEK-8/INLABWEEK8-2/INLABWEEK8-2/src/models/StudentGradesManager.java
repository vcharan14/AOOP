package models;

import java.util.*;

public class StudentGradesManager {
    private Map<Integer, Set<String>> studentGrades;

    public StudentGradesManager() {
        this.studentGrades = new HashMap<>();
    }

    // Add a grade for a student ID
    public void addGrade(int studentID, String grade) {
        studentGrades.putIfAbsent(studentID, new HashSet<>());
        studentGrades.get(studentID).add(grade);
        System.out.println("Grade added: " + grade + " for Student ID: " + studentID);
    }

    // Get all grades of a student by their ID
    public Set<String> getGrades(int studentID) {
        return studentGrades.getOrDefault(studentID, Collections.emptySet());
    }

    // Display all students and their grades
    public void displayAllGrades() {
        if (studentGrades.isEmpty()) {
            System.out.println("No student records available.");
            return;
        }
        System.out.println("\n--- Student Grades ---");
        studentGrades.forEach((id, grades) -> 
            System.out.println("Student ID: " + id + " -> Grades: " + grades));
    }
}
