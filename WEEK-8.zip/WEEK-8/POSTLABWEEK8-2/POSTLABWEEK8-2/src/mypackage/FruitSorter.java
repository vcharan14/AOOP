package mypackage;

import java.util.Set;
import java.util.TreeSet;

public class FruitSorter {
    public static void main(String[] args) {
        // Using TreeSet to store fruits (automatically sorted in natural order)
        Set<String> fruits = new TreeSet<>();

        // Adding fruits to the Set
        fruits.add("Mango");
        fruits.add("Banana");
        fruits.add("Apple");
        fruits.add("Orange");
        fruits.add("Grapes");

        // Printing fruits in alphabetical order
        System.out.println("Fruits in Alphabetical Order:");
        for (String fruit : fruits) {
            System.out.println(fruit);
        }
    }
}
