package mypackage;

import java.util.Set;
import java.util.HashSet;

public class MaxValueWithStream {
    public static void main(String[] args) {
        // Creating a Set of Integers
        Set<Integer> numbers = new HashSet<>();
        numbers.add(10);
        numbers.add(25);
        numbers.add(7);
        numbers.add(42);
        numbers.add(15);

        // Finding the maximum value using Stream API
        int maxValue = numbers.stream().max(Integer::compareTo).orElseThrow();

        // Displaying the maximum value
        System.out.println("Maximum Value: " + maxValue);
    }
}
