package mypackage;

import java.util.Set;
import java.util.HashSet;
import java.util.Collections;

public class MaxValueFinder {
    public static void main(String[] args) {
        // Creating a Set of Integers
        Set<Integer> numbers = new HashSet<>();
        numbers.add(10);
        numbers.add(25);
        numbers.add(7);
        numbers.add(42);
        numbers.add(15);

        // Finding the maximum value using Collections.max()
        int maxValue = Collections.max(numbers);

        // Displaying the maximum value
        System.out.println("Maximum Value: " + maxValue);
    }
}
