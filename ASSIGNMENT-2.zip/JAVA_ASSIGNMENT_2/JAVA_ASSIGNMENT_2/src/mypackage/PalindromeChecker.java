package mypackage;

class PalindromeChecker {
    public static boolean checkPalindrome(String str) {
        int left = 0, right = str.length() - 1;
        
        while (left < right) {
            if (str.charAt(left) != str.charAt(right)) {
                return false;
            }
            left++;
            right--;
        }
        return true;
    }
}

class PalindromeThread extends Thread {
    private final String str;

    // Constructor
    public PalindromeThread(String str) {
        this.str = str;
    }

    @Override
    public void run() {
        boolean result = PalindromeChecker.checkPalindrome(str);
        System.out.println("String: \"" + str + "\" → Palindrome? " + result);
    }
}

