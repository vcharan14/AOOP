package mypackage;

public class Main {
    public static void main(String[] args) {
        // List of strings to check
        String[] words = {"racecar", "hello", "madam", "level", "world"};

        // Create and start a thread for each word
        for (String word : words) {
            Thread thread = new PalindromeThread(word);
            thread.start();
        }
    }
}
