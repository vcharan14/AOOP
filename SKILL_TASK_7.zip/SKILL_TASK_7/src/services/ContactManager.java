package services;

import models.Contact;
import java.util.*;

public class ContactManager {
    private Set<Contact> contacts; // Ensures unique contacts
    private Map<String, Contact> contactMap; // Key-Value pair for fast lookup

    public ContactManager() {
        this.contacts = new HashSet<>();
        this.contactMap = new HashMap<>();
    }

    // Add contact
    public boolean addContact(Contact contact) {
        if (contacts.add(contact)) { // Only adds if unique
            contactMap.put(contact.getName().toLowerCase(), contact);
            return true;
        }
        return false; // Contact already exists
    }

    // Remove contact by name
    public boolean removeContact(String name) {
        Contact contact = contactMap.remove(name.toLowerCase());
        if (contact != null) {
            contacts.remove(contact);
            return true;
        }
        return false;
    }

    // Search contact by name
    public Contact searchContact(String name) {
        return contactMap.get(name.toLowerCase());
    }

    // Display all contacts
    public void displayContacts() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts available.");
        } else {
            for (Contact contact : contacts) {
                System.out.println(contact);
            }
        }
    }
}
