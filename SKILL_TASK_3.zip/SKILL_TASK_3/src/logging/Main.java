package logging;

public class Main {
    public static void main(String[] args) {
        Logger loggerChain = LoggerChain.getLoggerChain();

        System.out.println("Logging messages:");
        loggerChain.logMessage(Logger.INFO, "This is an informational message.");
        loggerChain.logMessage(Logger.DEBUG, "This is a debug message.");
        loggerChain.logMessage(Logger.ERROR, "This is an error message.");
    }
}
