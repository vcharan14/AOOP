/**
 * 
 */
/**
 * 
 */
module SKILL_TASK_3 {
}