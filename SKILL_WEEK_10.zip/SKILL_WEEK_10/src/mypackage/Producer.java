package mypackage;

class Producer extends Thread {
    private MessageQueue messageQueue;

    // Constructor
    public Producer(MessageQueue messageQueue) {
        this.messageQueue = messageQueue;
    }

    // Run Method (Thread Execution)
    public void run() {
        int messageCount = 1;
        while (messageCount <= 5) { // Produce 5 messages
            try {
                String message = "Message " + messageCount;
                messageQueue.produce(message);
                Thread.sleep(1000); // Simulate delay
                messageCount++;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
