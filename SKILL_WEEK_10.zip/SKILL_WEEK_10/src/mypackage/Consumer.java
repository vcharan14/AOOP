package mypackage;

class Consumer extends Thread {
    private MessageQueue messageQueue;

    // Constructor
    public Consumer(MessageQueue messageQueue) {
        this.messageQueue = messageQueue;
    }

    // Run Method (Thread Execution)
    public void run() {
        int messageCount = 1;
        while (messageCount <= 5) { // Consume 5 messages
            try {
                messageQueue.consume();
                Thread.sleep(1500); // Simulate processing delay
                messageCount++;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
