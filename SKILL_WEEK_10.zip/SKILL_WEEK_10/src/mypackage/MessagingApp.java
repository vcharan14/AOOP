package mypackage;

public class MessagingApp {
    public static void main(String[] args) {
        MessageQueue messageQueue = new MessageQueue(3); // Buffer size = 3

        Producer producer = new Producer(messageQueue);
        Consumer consumer = new Consumer(messageQueue);

        // Start threads
        producer.start();
        consumer.start();
    }
}
