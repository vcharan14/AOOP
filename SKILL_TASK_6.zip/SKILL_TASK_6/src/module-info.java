/**
 * 
 */
/**
 * 
 */
module SKILL_TASK_6 {
}