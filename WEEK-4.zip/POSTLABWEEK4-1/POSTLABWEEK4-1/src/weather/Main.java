package weather;

public class Main {
    public static void main(String[] args) {
        WeatherStation weatherStation = new WeatherStation();

        CurrentConditionsDisplay currentDisplay = new CurrentConditionsDisplay();
        StatisticsDisplay statisticsDisplay = new StatisticsDisplay();
        ForecastDisplay forecastDisplay = new ForecastDisplay();

        weatherStation.registerObserver(currentDisplay);
        weatherStation.registerObserver(statisticsDisplay);
        weatherStation.registerObserver(forecastDisplay);

        System.out.println("First Weather Update:");
        weatherStation.setWeatherData(25.5f, 65.0f, 1012.0f);

        System.out.println("\nSecond Weather Update:");
        weatherStation.setWeatherData(27.8f, 70.0f, 1013.5f);

        System.out.println("\nThird Weather Update:");
        weatherStation.setWeatherData(22.4f, 60.0f, 1009.0f);
    }
}
