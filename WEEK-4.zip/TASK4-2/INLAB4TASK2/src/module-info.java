/**
 * 
 */
/**
 * 
 */
module INLAB4TASK2 {
}