package com.example.notifications;

public abstract class NotificationService {
    // Template method
    public final void sendNotification(String user, String message) {
        prepareNotification(user);
        sendMessage(user, message);
        logNotification(user);
    }

    protected abstract void prepareNotification(String user);
    protected abstract void sendMessage(String user, String message);

    private void logNotification(String user) {
        System.out.println("Notification sent to: " + user);
    }
}
