package com.example.notifications;

public class NotificationSystem {
    public static void main(String[] args) {
        // Creating notification services
        NotificationService emailService = new EmailNotificationService();
        NotificationService smsService = new SMSNotificationService();
        NotificationService pushService = new PushNotificationService();

        // Dependency Injection: Injecting specific services into notifiers
        Notifier emailNotifier = new Notifier(emailService);
        Notifier smsNotifier = new Notifier(smsService);
        Notifier pushNotifier = new Notifier(pushService);

        // Observer Pattern: Creating a user event manager
        UserEventManager eventManager = new UserEventManager();

        // Adding observers for specific events
        eventManager.addObserver(event -> {
            if ("UserRegistration".equals(event)) {
                emailNotifier.notifyUser("user@example.com", "Welcome to our service!");
            }
        });

        eventManager.addObserver(event -> {
            if ("PasswordReset".equals(event)) {
                smsNotifier.notifyUser("+123456789", "Your password reset code is 12345.");
            }
        });

        eventManager.addObserver(event -> {
            if ("NewMessage".equals(event)) {
                pushNotifier.notifyUser("user123", "You have a new message!");
            }
        });

        // Triggering events
        System.out.println("Triggering UserRegistration event:");
        eventManager.triggerEvent("UserRegistration");

        System.out.println("\nTriggering PasswordReset event:");
        eventManager.triggerEvent("PasswordReset");

        System.out.println("\nTriggering NewMessage event:");
        eventManager.triggerEvent("NewMessage");
    }
}
