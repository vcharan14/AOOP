package com.example.notifications;

import java.util.ArrayList;
import java.util.List;

public class UserEventManager {
    private final List<UserEventObserver> observers = new ArrayList<>();

    public void addObserver(UserEventObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(UserEventObserver observer) {
        observers.remove(observer);
    }

    public void triggerEvent(String event) {
        for (UserEventObserver observer : observers) {
            observer.onEvent(event);
        }
    }
}
