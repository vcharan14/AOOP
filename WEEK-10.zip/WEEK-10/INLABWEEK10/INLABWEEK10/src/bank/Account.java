package bank;

public class Account {
    private double balance;

    public Account(int accountNumber, double balance) {
        this.balance = balance;
    }

    // Synchronized deposit method
    public synchronized void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println(Thread.currentThread().getName() + " Deposited: $" + amount + " | New Balance: $" + balance);
        }
    }

    // Synchronized withdraw method
    public synchronized void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println(Thread.currentThread().getName() + " Withdrawn: $" + amount + " | New Balance: $" + balance);
        } else {
            System.out.println(Thread.currentThread().getName() + " Insufficient Funds | Withdrawal Denied!");
        }
    }

    public double getBalance() {
        return balance;
    }
}
