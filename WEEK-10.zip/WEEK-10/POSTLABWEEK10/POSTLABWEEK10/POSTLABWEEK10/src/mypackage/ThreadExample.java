package mypackage;

public class ThreadExample {
    public static void main(String[] args) {
        FibonacciThread fibThread = new FibonacciThread();
        fibThread.start();

        // Creating and starting the Reverse thread
        ReverseThread revThread = new ReverseThread();
        revThread.start();
    }
}
