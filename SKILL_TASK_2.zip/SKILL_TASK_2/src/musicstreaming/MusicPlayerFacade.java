package musicstreaming;

public class MusicPlayerFacade {
    private MusicPlayer basicPlayer;
    private MusicSource localMusic;
    private MusicSource onlineMusic;
    private MusicSource radioMusic;

    public MusicPlayerFacade() {
        basicPlayer = new BasicMusicPlayer();
        localMusic = new LocalFileMusic("song.mp3");
        onlineMusic = new OnlineStreamMusic("https://example.com/stream");
        radioMusic = new RadioStationMusic("Radio XYZ");
    }

    public void playLocalMusic() {
        basicPlayer.play();
        localMusic.playMusic();
    }

    public void playOnlineMusic() {
        basicPlayer.play();
        onlineMusic.playMusic();
    }

    public void playRadio() {
        basicPlayer.play();
        radioMusic.playMusic();
    }

    public void playEnhancedOnlineMusic() {
        MusicPlayer enhancedPlayer = new EnhancedMusicPlayer(basicPlayer);
        enhancedPlayer.play();
        onlineMusic.playMusic();
    }
}
