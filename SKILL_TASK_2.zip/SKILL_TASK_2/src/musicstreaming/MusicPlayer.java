package musicstreaming;

public interface MusicPlayer {
    void play();
}
