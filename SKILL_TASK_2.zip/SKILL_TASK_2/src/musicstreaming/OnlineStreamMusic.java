package musicstreaming;

public class OnlineStreamMusic implements MusicSource {
    private String url;

    public OnlineStreamMusic(String url) {
        this.url = url;
    }

    @Override
    public void playMusic() {
        System.out.println("Streaming music from url: " + url);
    }
}
