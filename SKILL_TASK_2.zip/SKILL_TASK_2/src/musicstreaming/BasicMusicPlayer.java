package musicstreaming;

public class BasicMusicPlayer implements MusicPlayer {
    @Override
    public void play() {
        System.out.println("Using basic player");
    }
}
