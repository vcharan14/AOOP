package musicstreaming;

public class LocalFileMusic implements MusicSource {
    private String fileName;

    public LocalFileMusic(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public void playMusic() {
        System.out.println("Playing music from local file: " + fileName);
    }
}
