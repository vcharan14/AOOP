package musicstreaming;

public class EnhancedMusicPlayer implements MusicPlayer {
    private MusicPlayer musicPlayer;

    public EnhancedMusicPlayer(MusicPlayer musicPlayer) {
        this.musicPlayer = musicPlayer;
    }

    public void applyEqualizer() {
        System.out.println("Applying equalizer settings...");
    }

    public void adjustVolume() {
        System.out.println("Adjusting volume...");
    }

    @Override
    public void play() {
        applyEqualizer();
        adjustVolume();
        musicPlayer.play();
    }
}
