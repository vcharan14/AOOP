package employeesort;

import java.util.Comparator;

// Comparator to sort by Salary (Ascending)
class SalaryAscendingComparator implements Comparator<Employee> {
    @Override
    public int compare(Employee e1, Employee e2) {
        return Double.compare(e1.getSalary(), e2.getSalary());
    }
}

// Comparator to sort by Salary (Descending)
class SalaryDescendingComparator implements Comparator<Employee> {
    @Override
    public int compare(Employee e1, Employee e2) {
        return Double.compare(e2.getSalary(), e1.getSalary());
    }
}

// Comparator to sort by Name (Alphabetical Order)
class NameComparator implements Comparator<Employee> {
    @Override
    public int compare(Employee e1, Employee e2) {
        return e1.getName().compareToIgnoreCase(e2.getName());
    }
}

// Comparator to sort by Department (Alphabetical Order)
class DepartmentComparator implements Comparator<Employee> {
    @Override
    public int compare(Employee e1, Employee e2) {
        return e1.getDepartment().compareToIgnoreCase(e2.getDepartment());
    }
}
