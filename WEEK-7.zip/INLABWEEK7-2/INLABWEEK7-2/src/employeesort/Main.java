package employeesort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Creating a list of employees
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(101, "Alice", "HR", 50000));
        employees.add(new Employee(102, "Bob", "IT", 70000));
        employees.add(new Employee(103, "Charlie", "Finance", 60000));
        employees.add(new Employee(104, "David", "IT", 80000));
        employees.add(new Employee(105, "Eve", "HR", 55000));

        // Sorting by Salary (Ascending)
        System.out.println("Sorted by Salary (Ascending):");
        Collections.sort(employees, new SalaryAscendingComparator());
        for (Employee emp : employees) {
            System.out.println(emp);
        }

        // Sorting by Salary (Descending)
        System.out.println("\nSorted by Salary (Descending):");
        Collections.sort(employees, new SalaryDescendingComparator());
        for (Employee emp : employees) {
            System.out.println(emp);
        }

        // Sorting by Name (Alphabetical Order)
        System.out.println("\nSorted by Name:");
        Collections.sort(employees, new NameComparator());
        for (Employee emp : employees) {
            System.out.println(emp);
        }

        // Sorting by Department (Alphabetical Order)
        System.out.println("\nSorted by Department:");
        Collections.sort(employees, new DepartmentComparator());
        for (Employee emp : employees) {
            System.out.println(emp);
        }
    }
}
