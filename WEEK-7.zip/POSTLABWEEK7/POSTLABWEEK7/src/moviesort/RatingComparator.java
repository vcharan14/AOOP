package moviesort;

import java.util.Comparator;

// Comparator to sort by Rating (Ascending)
class RatingComparator implements Comparator<Movie> {
    @Override
    public int compare(Movie m1, Movie m2) {
        return Double.compare(m1.getRating(), m2.getRating());
    }
}

// Comparator to sort by Name (Alphabetical Order)
class NameComparator implements Comparator<Movie> {
    @Override
    public int compare(Movie m1, Movie m2) {
        return m1.getName().compareToIgnoreCase(m2.getName());
    }
}

// Comparator to sort by Year (Ascending)
class YearComparator implements Comparator<Movie> {
    @Override
    public int compare(Movie m1, Movie m2) {
        return Integer.compare(m1.getYear(), m2.getYear());
    }
}
