package moviesort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Creating a list of movies
        List<Movie> movies = new ArrayList<>();
        movies.add(new Movie(8.4, "Return of the Jedi", 1983));
        movies.add(new Movie(8.8, "Empire Strikes Back", 1980));
        movies.add(new Movie(8.3, "Force Awakens", 2015));
        movies.add(new Movie(8.7, "Star Wars", 1977));

        // Sorting by Rating
        System.out.println("Sorted by rating:");
        Collections.sort(movies, new RatingComparator());
        for (Movie movie : movies) {
            System.out.println(movie);
        }

        // Sorting by Name
        System.out.println("\nSorted by name:");
        Collections.sort(movies, new NameComparator());
        for (Movie movie : movies) {
            System.out.println(movie.getName() + " " + movie.getRating() + " " + movie.getYear());
        }

        // Sorting by Year
        System.out.println("\nSorted by year:");
        Collections.sort(movies, new YearComparator());
        for (Movie movie : movies) {
            System.out.println(movie.getYear() + " " + movie.getRating() + " " + movie.getName());
        }
    }
}
