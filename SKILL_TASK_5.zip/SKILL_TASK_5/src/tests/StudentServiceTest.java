package tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import models.GraduateStudent;
import models.UndergraduateStudent;
import services.StudentService;

public class StudentServiceTest {
    private StudentService studentService;

    @BeforeEach
    void setUp() {
        studentService = new StudentService();
    }

    @Test
    void testAddAndRetrieveStudent() {
        UndergraduateStudent student = new UndergraduateStudent(1, "Alice", "CSE", 3);
        studentService.addStudent(student);
        
        assertEquals("Alice", studentService.getStudentById(1).getName());
    }

    @Test
    void testRetrieveNonExistentStudent() {
        assertNull(studentService.getStudentById(99));
    }
}
