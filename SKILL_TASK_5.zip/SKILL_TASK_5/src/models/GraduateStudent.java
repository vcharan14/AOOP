package models;

public class GraduateStudent extends Student {
    private String researchTopic;

    public GraduateStudent(int id, String name, String department, String researchTopic) {
        super(id, name, department);
        this.researchTopic = researchTopic;
    }

    public String getResearchTopic() { return researchTopic; }

    @Override
    public void displayInfo() {
        System.out.println("Graduate Student: " + name + " (Research: " + researchTopic + ")");
    }
}
