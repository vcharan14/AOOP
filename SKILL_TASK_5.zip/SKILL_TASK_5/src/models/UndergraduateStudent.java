package models;

public class UndergraduateStudent extends Student {
    private int year;

    public UndergraduateStudent(int id, String name, String department, int year) {
        super(id, name, department);
        this.year = year;
    }

    public int getYear() { return year; }

    @Override
    public void displayInfo() {
        System.out.println("Undergraduate Student: " + name + " (Year " + year + ")");
    }
}
