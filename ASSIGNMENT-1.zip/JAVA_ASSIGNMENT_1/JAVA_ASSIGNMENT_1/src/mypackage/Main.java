package mypackage;

public class Main {
    public static void main(String[] args) {
        MusicPlayer player = new MusicPlayer();

        // Create and start threads
        Thread songLoader = new SongLoader(player);
        Thread songPlayer = new SongPlayer(player);
        Thread playbackController = new PlaybackController(player);

        songLoader.start();
        songPlayer.start();
        playbackController.start();
    }
}
