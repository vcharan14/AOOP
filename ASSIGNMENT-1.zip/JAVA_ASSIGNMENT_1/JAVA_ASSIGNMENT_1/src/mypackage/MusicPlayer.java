package mypackage;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

// Shared class for Music Player
class MusicPlayer {
    private final Queue<String> songQueue = new LinkedList<>();
    private boolean isPaused = false; // Control playback

    // Method to add songs to the queue (Thread-Safe)
    public synchronized void addSong(String song) {
        songQueue.offer(song);
        System.out.println("🎵 Song Loaded: " + song);
        notify(); // Notify the player thread to play the song
    }

    // Method to play songs
    public synchronized void playSongs() {
        while (true) {
            while (songQueue.isEmpty()) {
                try {
                    System.out.println("🎶 Waiting for songs...");
                    wait(); // Wait until new songs are loaded
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            // Play the song if not paused
            while (!songQueue.isEmpty()) {
                synchronized (this) {
                    while (isPaused) { // If paused, wait
                        try {
                            System.out.println("⏸ Playback Paused...");
                            wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }

                String song = songQueue.poll();
                System.out.println("▶ Now Playing: " + song);
                try {
                    Thread.sleep(3000); // Simulating song play for 3 sec
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Toggle Play/Pause
    public synchronized void togglePause() {
        isPaused = !isPaused;
        if (!isPaused) {
            System.out.println("▶ Resuming Playback...");
            notifyAll(); // Resume the player thread
        }
    }
}

// Thread for Loading Songs
class SongLoader extends Thread {
    private final MusicPlayer player;

    public SongLoader(MusicPlayer player) {
        this.player = player;
    }

    @Override
    public void run() {
        String[] songs = {"Song A", "Song B", "Song C", "Song D"};
        for (String song : songs) {
            player.addSong(song);
            try {
                Thread.sleep(2000); // Simulate loading time
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

// Thread for Playing Songs
class SongPlayer extends Thread {
    private final MusicPlayer player;

    public SongPlayer(MusicPlayer player) {
        this.player = player;
    }

    @Override
    public void run() {
        player.playSongs();
    }
}

// Thread for Controlling Playback
class PlaybackController extends Thread {
    private final MusicPlayer player;

    public PlaybackController(MusicPlayer player) {
        this.player = player;
    }

    @Override
    public void run() {
        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                System.out.println("Press 'p' to Pause/Resume:");
                String input = scanner.next();
                if ("p".equalsIgnoreCase(input)) {
                    player.togglePause();
                }
            }
        }
    }
}


